## 🧩 Aggregate Roots

Aggregates are the **core building blocks** of your domain model — they encapsulate state and enforce invariants through
event-driven or state-driven updates.

In Pillar, all aggregates extend the abstract base class `AggregateRoot`, which provides a consistent pattern for *
*recording and applying domain events**, while still allowing simpler state-backed persistence when full event sourcing
isn’t needed.

---

### Example (Event-Sourced Aggregate)

```php
use Pillar\Aggregate\AggregateRoot;
use Pillar\Snapshot\Snapshottable;
use Context\Document\Domain\Event\DocumentCreated;
use Context\Document\Domain\Event\DocumentRenamed;
use Context\Document\Domain\Identifier\DocumentId;

final class Document extends AggregateRoot implements Snapshottable
{
    private DocumentId $id;
    private string $title;

    public static function create(DocumentId $id, string $title): self
    {
        $self = new self();
        $self->record(new DocumentCreated($id, $title));
        return $self;
    }

    public function rename(string $newTitle): void
    {
        if ($this->title === $newTitle) {
            return;
        }

        $this->record(new DocumentRenamed($this->id(), $newTitle));
    }

    protected function applyDocumentCreated(DocumentCreated $event): void
    {
        $this->id = $event->id;
        $this->title = $event->title;
    }

    protected function applyDocumentRenamed(DocumentRenamed $event): void
    {
        $this->title = $event->newTitle;
    }

    // Snapshottable
    public function toSnapshot(): array
    {
        return [
            'id' => (string) $this->id,
            'title' => $this->title,
        ];
    }

    public static function fromSnapshot(array $data): static
    {
        $self = new self();
        $self->id = DocumentId::from($data['id']);
        $self->title = $data['title'];
        return $self;
    }

    public function id(): DocumentId
    {
        return $this->id;
    }
}
```

This is the **event-sourced** approach — every state change is expressed as a **domain event**, persisted to the event
store, and used to rebuild the aggregate’s state later.

This model gives you:

- 🔍 **Full auditability** of all domain changes over time
- 🕰️ **Reproducibility** and replay capability
- ⚙️ **Resilience** against schema evolution with versioned events and upcasters

---

### Example (State-Based Aggregate)

For simpler domains, you can skip event sourcing entirely.
In that case, your repository can directly persist and retrieve aggregates from a storage backend (like Eloquent or a
document store).
You don’t record or apply events — you just mutate the state directly.

```php
use Context\Document\Domain\Identifier\DocumentId;
use Pillar\Aggregate\AggregateRoot;
use Pillar\Snapshot\Snapshottable;

final class Document extends AggregateRoot implements Snapshottable
{
    public function __construct(
        private DocumentId $id,
        private string $title
    ) {}

    public function rename(string $newTitle): void
    {
        $this->title = $newTitle;
    }

    // Snapshottable
    public function toSnapshot(): array
    {
        return [
            'id' => (string) $this->id,
            'title' => $this->title,
        ];
    }

    public static function fromSnapshot(array $data): static
    {
        return new self(DocumentId::from($data['id']), $data['title']);
    }

    public function id(): DocumentId
    {
        return $this->id;
    }
}
```

This **state-based** model is ideal for:

- 🧾 Aggregates that don’t require **audit trails** or **historical replay**
- ⚡ Domains that favor **direct persistence** over event sourcing
- 🧰 Use cases where you want the same aggregate behavior API but backed by a simpler repository

Both models work seamlessly with Pillar’s repository and session abstractions — you can mix and match them in the same
application.



#### Wiring a state‑based aggregate with Eloquent

For state‑based aggregates, the repository persists fields directly (no events). Here’s a minimal Eloquent mapping with **optimistic concurrency** via a `version` column:

```php
// app/Models/DocumentRecord.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentRecord extends Model
{
    protected $table = 'documents';
    public $timestamps = false;
    protected $fillable = ['id', 'title', 'version'];
}
```

```
**Migration (documents table)**

```php
// database/migrations/XXXX_XX_XX_000000_create_documents_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('documents', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->unsignedBigInteger('version')->default(0); // optional for optimistic locking
        });
    }

    public function down(): void {
        Schema::dropIfExists('documents');
    }
};
```

```php
// app/Context/Document/Infrastructure/DocumentRepository.php
namespace App\Context\Document\Infrastructure;

use Pillar\Repository\AggregateRepository;
use Pillar\Repository\LoadedAggregate;
use Pillar\Aggregate\AggregateRootId;
use App\Models\DocumentRecord;
use Context\Document\Domain\Aggregate\Document;   // your aggregate class
use Context\Document\Domain\Identifier\DocumentId;

final class DocumentRepository implements AggregateRepository
{
    public function find(AggregateRootId $id): ?LoadedAggregate
    {
        $row = DocumentRecord::query()->whereKey((string) $id)->first();
        if (! $row) {
            return null;
        }

        $aggregate = new Document(DocumentId::from($row->id), $row->title);
        $version = (int) ($row->version ?? 0);

        return new LoadedAggregate($aggregate, $version);
    }

    public function save(\Pillar\Aggregate\AggregateRoot $aggregate, ?int $expectedVersion = null): void
    {
        /** @var Document $aggregate */
        $id = (string) $aggregate->id();

        // Upsert with optimistic locking on "version"
        $row = DocumentRecord::query()->whereKey($id)->lockForUpdate()->first();
        if ($row) {
            if ($expectedVersion !== null && (int) $row->version !== $expectedVersion) {
                throw new \RuntimeException('Concurrency conflict for Document '.$id);
            }

            $row->title = $aggregate->title;
            $row->version = (int) ($row->version ?? 0) + 1;
            $row->save();
        } else {
            // first write
            DocumentRecord::create([
                'id' => $id,
                'title' => $aggregate->title,
                'version' => 1,
            ]);
        }
    }
}
```


> **Optional:** optimistic locking via a `version` column is **not required**. If you don’t need it, remove the `version` column from the migration, drop `lockForUpdate()` and the `$expectedVersion` check, and stop incrementing `$row->version`. The repository will still work, just without concurrency guarantees.

Register the repository for this aggregate in `config/pillar.php`:

```php
'repositories' => [
    'default' => Pillar\Repository\EventStoreRepository::class,
    Context\Document\Domain\Aggregate\Document::class => App\Context\Document\Infrastructure\DocumentRepository::class,
],
```

Now a command handler can load and save via the **AggregateSession** (no event store involved):

```php
$doc = $session->find(DocumentId::from($id));
$doc->rename('New Title');
$session->commit(); // persists through DocumentRepository
```


---

### 🧠 Aggregate Lifecycle Overview

```mermaid
sequenceDiagram
    participant Client
    participant CommandHandler
    participant Aggregate
    participant Session
    participant Repository
    participant EventStore

    Client ->> CommandHandler: Send command
    CommandHandler ->> Session: find(AggregateId)
    Session ->> Repository: load(Aggregate)
    Repository ->> EventStore: load events
    EventStore -->> Repository: return events
    Repository -->> Session: reconstituted aggregate
    CommandHandler ->> Aggregate: execute method (rename())
    Aggregate ->> Aggregate: record(event)
    Aggregate ->> Session: releaseEvents()
    Session ->> Repository: save(Aggregate)
    Repository ->> EventStore: append events
    Session -->> Client: commit complete
```

*(For state-based aggregates, the “EventStore” step is replaced with a direct database update.)*

---